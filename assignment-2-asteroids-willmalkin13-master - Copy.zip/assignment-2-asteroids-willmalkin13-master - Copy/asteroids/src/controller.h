/* Main control method */
void controls(void);
